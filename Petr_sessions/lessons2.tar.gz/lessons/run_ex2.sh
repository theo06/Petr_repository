#!/bin/sh

./bin/ex2.1
echo
./bin/ex2.2
echo
./bin/ex2.3
echo
./bin/ex2.4
echo
./bin/ex2.5
echo
./bin/ex2.6
