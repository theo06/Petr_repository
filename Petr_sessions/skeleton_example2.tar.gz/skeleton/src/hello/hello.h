#ifndef __HELLO_H__
#define __HELLO_H__

int hello();
int fail_hello();
int warn_hello();
int debug_hello();



#endif /* __HELLO_H__ */
